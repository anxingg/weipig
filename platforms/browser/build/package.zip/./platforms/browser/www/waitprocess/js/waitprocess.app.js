var waitProcessApp=angular.module('waitProcess.app', ['ionic','common.app','weipig.api']);
